import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import LoginInput from './index';

describe('LoginInput Component', () => {
  it('should call the login function with email and password when submitted', () => {
    const mockLogin = vi.fn();
    render(<LoginInput login={mockLogin} />);

    const emailInput = screen.getByPlaceholderText('Email');
    const passwordInput = screen.getByPlaceholderText('Password');
    const submitButton = screen.getByRole('button', { name: /login/i });

    fireEvent.change(emailInput, { target: { value: 'test@example.com' } });
    fireEvent.change(passwordInput, { target: { value: 'password123' } });
    fireEvent.click(submitButton);

    expect(mockLogin).toHaveBeenCalledWith({
      email: 'test@example.com',
      password: 'password123',
    });
  });

  it('should not call the login function if email or password is missing', () => {
    const mockLogin = vi.fn();
    render(<LoginInput login={mockLogin} />);

    const submitButton = screen.getByRole('button', { name: /Login/i });
    fireEvent.click(submitButton);

    expect(mockLogin).not.toHaveBeenCalled();
  });
});
