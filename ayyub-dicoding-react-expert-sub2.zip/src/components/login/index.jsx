import React from 'react';
import PropTypes from 'prop-types';
import useInputs from '../../hooks/useInputs';

const LoginInput = ({ login }) => {
  const [email, onEmailChange] = useInputs('');
  const [password, onPasswordChange] = useInputs('');

  const onSubmit = (e) => {
    e.preventDefault();
    if (email && password) {
      login({ email, password });
    }
  };

  return (
    <fieldset className="fieldset bg-base-300 border-base-300 rounded-box w-xs border p-4">
      <legend className="fieldset-legend">Login</legend>
      <form onSubmit={onSubmit}>
        <label className="label" htmlFor="email">Email</label>
        <input
          type="email"
          id="email"
          className="input"
          placeholder="Email"
          value={email}
          onChange={onEmailChange}
          required
        />
        <label className="label" htmlFor="password">Password</label>
        <input
          type="password"
          id="password"
          className="input"
          placeholder="Password"
          value={password}
          onChange={onPasswordChange}
          required
        />
        <button type="submit" className="btn btn-primary mt-4 w-full">
          Login
        </button>
      </form>
    </fieldset>
  );
};

LoginInput.propTypes = {
  login: PropTypes.func.isRequired,
};

export default LoginInput;