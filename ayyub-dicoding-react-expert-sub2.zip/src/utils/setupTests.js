import '@testing-library/jest-dom';
import { cleanup } from '@testing-library/react';
import { afterEach, vi } from 'vitest';

global.vi = vi;
afterEach(() => {
  cleanup();
});