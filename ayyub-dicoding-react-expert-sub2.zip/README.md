# Proyek: Membangun Aplikasi React dengan Redux

Submission 1 React Web Developer Expert, <br/> Proyek: Membangun Aplikasi React dengan Redux

```
bun install
bun run dev
```

## Fitur
- eslint-config-dicodingacademy
- react router
- react-redux
- react-redux-loading-bar
- prop-types
